<?php
  $arc = $_POST['arc'];
  $level = $_POST['level'];
  $deaths = $_POST['deaths'];
  $stars = $_POST['stars'];
  $
?>
