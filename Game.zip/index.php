<!DOCTYPE html>
<html>
<title>Game - Homepage</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="js/p5.js"></script>
<script src="js/jquery-3.2.1.js"></script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="css/main.css">
<body style="background-color:black;">

<div id="middle">
			
			<a href="game.php">
			<div id="play-btn" class="w3-btn w3-black">
			PLAY
			<div>
			</a>
</div>

</body>
</html>