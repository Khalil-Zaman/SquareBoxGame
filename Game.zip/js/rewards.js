var coins = [0, 1, 1, 1];
var coin_rotation = 1;

function coin_reset(){
	coins = [0, 1, 1, 1];
}