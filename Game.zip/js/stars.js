var stars;
var stars_rotation = 1;
var level_completed;

function initialize_star_variables(){
	stars = [0, 1, 1, 1];
	level_completed = false;
}

function stars_reset(){
	stars = [0, 1, 1, 1];
}
